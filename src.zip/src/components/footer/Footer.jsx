import React, { useState } from 'react';
import './footer.css';

const Footer = () => {
    // --- ESTADOS PARA LOS 4 MODALES ---
    const [showFaq, setShowFaq] = useState(false);
    const [showTerms, setShowTerms] = useState(false);
    const [showRules, setShowRules] = useState(false);
    const [showTips, setShowTips] = useState(false); // <--- CAMBIO AQUÍ (Antes showReport)
    
    // Estado para el acordeón de preguntas
    const [selectedQuestion, setSelectedQuestion] = useState(null);

    // --- DATOS FAQ ---
    const faqData = [
        { question: "¿Quiénes pueden usar PoliParking?", answer: "Exclusivo para la comunidad EPN: estudiantes, profesores y administrativos con credenciales activas." },
        { question: "¿Cómo reservo un espacio?", answer: "Regístrate con tu correo institucional, inicia sesión y selecciona fecha/hora en tu Dashboard." },
        { question: "¿Tiene costo?", answer: "El uso de la aplicación es gratuito. El uso físico del parqueadero está sujeto a las tasas vigentes de la institución." },
        { question: "¿Qué es el tiempo de tolerancia?", answer: "Es el tiempo máximo (15 min) que guardamos tu lugar. Si no llegas, el sistema libera el espacio automáticamente." },
        { question: "¿Cómo cancelo una reserva?", answer: "Desde el Dashboard, presiona el botón 'Cancelar'. Debes hacerlo al menos 30 minutos antes para evitar sanciones." }
    ];

    const toggleQuestion = (i) => {
        if (selectedQuestion === i) return setSelectedQuestion(null);
        setSelectedQuestion(i);
    };

    return (
        <>
            <footer className="footer">
                <div className="footer__container">
                    <div className="footer-row">
                        
                        {/* COLUMNA 1: NAVEGACIÓN */}
                        <div className="footer__col">
                            <h3 className="footer__title">Navegación</h3>
                            <ul className="footer__list">
                                <li>
                                    <a href="#" onClick={(e) => { e.preventDefault(); setShowFaq(true); }}>
                                        Preguntas Frecuentes
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick={(e) => { e.preventDefault(); setShowTerms(true); }}>
                                        Términos y Condiciones
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick={(e) => { e.preventDefault(); setShowRules(true); }}>
                                        Reglamento de Uso
                                    </a>
                                </li>
                                <li>
                                    {/* CAMBIO AQUÍ: Tips de Seguridad en lugar de Reportar Incidente */}
                                    <a href="#" onClick={(e) => { e.preventDefault(); setShowTips(true); }}>
                                        Tips de Seguridad
                                    </a>
                                </li>
                            </ul>
                        </div>

                        {/* COLUMNA 2: HORARIOS ACTUALIZADA */}
<div className="footer__col">
    <h3 className="footer__title">Horarios de Atención</h3>
    <ul className="footer__list footer__list--hours">
        <li>
            <span className="hour-label">Lunes - Viernes</span>
            <span className="hour-value">06:30 - 20:00</span>
        </li>
        <li>
            <span className="hour-label">Sábados</span>
            <span className="hour-value">07:00 - 13:00</span>
        </li>
        <li>
            <span className="hour-label">Dom y Feriados</span>
            <span className="hour-value hour-value--special">Solo autorizados</span>
        </li>
    </ul>
</div>

                        {/* COLUMNA 3: ACCIÓN DIRECTA (INTACTA) */}
                        <div className="footer__col" style={{ justifyContent: 'center' }}>
                            <h3 className="footer__title">Empieza Ahora</h3>
                            <p style={{ fontSize: '0.9rem', marginBottom: '20px' }}>
                                ¿Listo para asegurar tu lugar?
                            </p>
                            
                            <a href="/login" style={{ 
                                display: 'block',
                                textAlign: 'center',
                                background: '#feca57', 
                                color: '#0a3d62', 
                                padding: '12px', 
                                borderRadius: '5px', 
                                textDecoration: 'none', 
                                fontWeight: 'bold',
                                fontSize: '1rem',
                                boxShadow: '0 4px 0 #d4a017',
                                transition: 'transform 0.1s'
                            }}>
                                <i className="fa-solid fa-calendar-check" style={{ marginRight: '8px' }}></i>
                                Reservar Estacionamiento
                            </a>
                            
                            <p style={{ fontSize: '0.8rem', marginTop: '10px', textAlign: 'center', opacity: 0.7 }}>
                                *Acceso exclusivo con correo EPN
                            </p>
                        </div>
                    </div>
                </div>
                
                <div className="footer__bottom">
                    <p>© {new Date().getFullYear()} PoliParking - Escuela Politécnica Nacional. Todos los derechos reservados.</p>
                </div>
            </footer>

            {/* =======================================================
                AREA DE MODALES (VENTANAS EMERGENTES)
               ======================================================= */}

            {/* 1. FAQ */}
            {showFaq && (
                <div className="modal-overlay" onClick={() => setShowFaq(false)}>
                    <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                        <div className="modal-header">
                            <h2 style={{color: '#0a3d62', margin: 0}}>Preguntas Frecuentes</h2>
                            <button className="close-btn" onClick={() => setShowFaq(false)}>×</button>
                        </div>
                        <div className="modal-body">
                            {faqData.map((item, i) => (
                                <div className="faq-item-modal" key={i} onClick={() => toggleQuestion(i)}>
                                    <div className="faq-question-modal">
                                        <span>{item.question}</span>
                                        <span style={{fontWeight:'bold', fontSize:'1.2rem'}}>{selectedQuestion === i ? '-' : '+'}</span>
                                    </div>
                                    <div className={selectedQuestion === i ? 'faq-answer-modal show' : 'faq-answer-modal'}>
                                        <p style={{margin: '10px 0 0', color: '#555'}}>{item.answer}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {/* 2. TÉRMINOS Y CONDICIONES */}
            {showTerms && (
                <div className="modal-overlay" onClick={() => setShowTerms(false)}>
                    <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                        <div className="modal-header">
                            <h2 style={{color: '#0a3d62', margin: 0}}>Términos y Condiciones</h2>
                            <button className="close-btn" onClick={() => setShowTerms(false)}>×</button>
                        </div>
                        <div className="modal-body" style={{lineHeight: '1.6', color: '#444', textAlign: 'justify'}}>
                            <p style={{marginBottom:'15px', fontStyle:'italic'}}>Última actualización: Febrero 2025</p>
                            <h4 style={{color:'#0a3d62', marginBottom:'5px'}}>1. Aceptación del Servicio</h4>
                            <p style={{marginBottom:'15px'}}>Al utilizar PoliParking, el usuario acepta cumplir con los presentes términos y con la normativa interna de la EPN.</p>
                            <h4 style={{color:'#0a3d62', marginBottom:'5px'}}>2. Uso de la Cuenta</h4>
                            <p style={{marginBottom:'15px'}}>La cuenta es <strong>personal e intransferible</strong>. El usuario es responsable de sus credenciales.</p>
                            <h4 style={{color:'#0a3d62', marginBottom:'5px'}}>3. Limitación de Responsabilidad</h4>
                            <p style={{marginBottom:'15px'}}>PoliParking no se hace responsable por robos ni daños parciales o totales a los vehículos dentro de las instalaciones.</p>
                            <h4 style={{color:'#0a3d62', marginBottom:'5px'}}>4. Datos Personales</h4>
                            <p style={{marginBottom:'15px'}}>Los datos recopilados serán tratados estrictamente para fines de seguridad y control de acceso.</p>
                        </div>
                    </div>
                </div>
            )}

            {/* 3. REGLAMENTO DE USO */}
            {showRules && (
                <div className="modal-overlay" onClick={() => setShowRules(false)}>
                    <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                        <div className="modal-header">
                            <h2 style={{color: '#0a3d62', margin: 0}}>Reglamento Interno</h2>
                            <button className="close-btn" onClick={() => setShowRules(false)}>×</button>
                        </div>
                        <div className="modal-body" style={{lineHeight: '1.6', color: '#444'}}>
                            <div style={{background:'#fdf2f2', borderLeft:'4px solid #e30613', padding:'10px', marginBottom:'20px'}}>
                                <strong>IMPORTANTE:</strong> El ingreso al campus implica la aceptación de estas normas. La vigilancia es permanente.
                            </div>
                            <ul style={{paddingLeft: '20px', listStyleType: 'circle'}}>
                                <li style={{marginBottom: '15px'}}><strong>Velocidad Máxima:</strong> La velocidad límite dentro del campus es de <strong>10 km/h</strong>.</li>
                                <li style={{marginBottom: '15px'}}><strong>Estacionamiento en Reversa:</strong> Por normas de seguridad, es <u>obligatorio</u> estacionar aculatado.</li>
                                <li style={{marginBottom: '15px'}}><strong>Espacios Reservados:</strong> Respetar zonas de discapacidad y autoridades.</li>
                                <li style={{marginBottom: '15px'}}><strong>Pernoctación:</strong> Prohibido dejar vehículos fuera del horario de atención.</li>
                                <li style={{marginBottom: '15px'}}><strong>Sanciones:</strong> Uso de cepo para vehículos mal estacionados.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            )}

            {/* 4. MODAL TIPS DE SEGURIDAD (NUEVO - REEMPLAZA A REPORTAR INCIDENTE) */}
            {showTips && (
                <div className="modal-overlay" onClick={() => setShowTips(false)}>
                    <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                        
                        <div className="modal-header">
                            <h2 style={{ color: '#0a3d62', margin: 0 }}>Tips de Seguridad Vial</h2>
                            <button className="close-btn" onClick={() => setShowTips(false)}>×</button>
                        </div>

                        <div className="modal-body" style={{ padding: '0 10px 20px' }}>
                            <p style={{ color: '#666', marginBottom: '20px', fontSize: '0.95rem' }}>
                                Cuida tu vehículo y tus pertenencias siguiendo estas recomendaciones:
                            </p>

                            <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
                                <li style={{ display: 'flex', alignItems: 'start', gap: '15px', marginBottom: '20px' }}>
                                    <div style={{ background: '#e3f2fd', color: '#1565c0', minWidth: '45px', height: '45px', borderRadius: '50%', display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '1.2rem' }}>
                                        <i className="fas fa-laptop"></i>
                                    </div>
                                    <div>
                                        <h4 style={{ margin: '0 0 5px 0', color: '#333' }}>Objetos de Valor</h4>
                                        <p style={{ margin: 0, fontSize: '0.9rem', color: '#666' }}>Evita dejar mochilas o laptops a la vista.</p>
                                    </div>
                                </li>

                                <li style={{ display: 'flex', alignItems: 'start', gap: '15px', marginBottom: '20px' }}>
                                    <div style={{ background: '#fff3e0', color: '#ef6c00', minWidth: '45px', height: '45px', borderRadius: '50%', display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '1.2rem' }}>
                                        <i className="fas fa-lock"></i>
                                    </div>
                                    <div>
                                        <h4 style={{ margin: '0 0 5px 0', color: '#333' }}>Cierre Seguro</h4>
                                        <p style={{ margin: 0, fontSize: '0.9rem', color: '#666' }}>Verifica que las ventanas estén cerradas.</p>
                                    </div>
                                </li>

                                <li style={{ display: 'flex', alignItems: 'start', gap: '15px', marginBottom: '20px' }}>
                                    <div style={{ background: '#e8f5e9', color: '#2e7d32', minWidth: '45px', height: '45px', borderRadius: '50%', display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '1.2rem' }}>
                                        <i className="fas fa-walking"></i>
                                    </div>
                                    <div>
                                        <h4 style={{ margin: '0 0 5px 0', color: '#333' }}>Peatones</h4>
                                        <p style={{ margin: 0, fontSize: '0.9rem', color: '#666' }}>Cede el paso siempre en los cruces cebra.</p>
                                    </div>
                                </li>

                                <li style={{ display: 'flex', alignItems: 'start', gap: '15px' }}>
                                    <div style={{ background: '#ffebee', color: '#c62828', minWidth: '45px', height: '45px', borderRadius: '50%', display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '1.2rem' }}>
                                        <i className="fas fa-car-battery"></i>
                                    </div>
                                    <div>
                                        <h4 style={{ margin: '0 0 5px 0', color: '#333' }}>Luces</h4>
                                        <p style={{ margin: 0, fontSize: '0.9rem', color: '#666' }}>Apaga las luces para cuidar tu batería.</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            )}

        </>
    );
};

export default Footer;